Good day, Reviewer

Below is my CloudFront endpoint URL for my project for your perusal;

https://d1auw5rzucdgye.cloudfront.net/

Thanks.